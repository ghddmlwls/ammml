document.addEventListener('DOMContentLoaded', () => {
  const dropdowns = document.querySelectorAll('.site-header .dropdown');
  const mobileQuery = window.matchMedia('(max-width: 768px)');

  const closeAll = (except = null) => {
    dropdowns.forEach((dropdown) => {
      if (dropdown === except) return;
      dropdown.classList.remove('mobile-open');
      const toggle = dropdown.querySelector(':scope > .dropdown-toggle');
      if (toggle) toggle.setAttribute('aria-expanded', 'false');
    });
  };

  dropdowns.forEach((dropdown) => {
    const toggle = dropdown.querySelector(':scope > .dropdown-toggle');
    if (!toggle) return;

    toggle.addEventListener('click', (event) => {
      if (!mobileQuery.matches) return;
      event.preventDefault();
      const willOpen = !dropdown.classList.contains('mobile-open');
      closeAll(dropdown);
      dropdown.classList.toggle('mobile-open', willOpen);
      toggle.setAttribute('aria-expanded', String(willOpen));
    });

    dropdown.querySelectorAll('.dropdown-menu a').forEach((link) => {
      link.addEventListener('click', () => {
        dropdown.classList.remove('mobile-open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  });

  document.addEventListener('click', (event) => {
    if (!mobileQuery.matches) return;
    if (!event.target.closest('.site-header .dropdown')) closeAll();
  });

  window.addEventListener('resize', () => {
    if (!mobileQuery.matches) closeAll();
  });
});
